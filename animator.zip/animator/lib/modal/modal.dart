class Model
{
  String? photo,name,about;

  Model({this.photo, this.name, this.about});
}